﻿namespace UltraDES
{
    public enum GraphVizStyle
    {
        solid,
        dashed,
        dotted,
        bold
    }
}
